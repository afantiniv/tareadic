﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnAgregar = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lbwhile = New System.Windows.Forms.ListBox()
        Me.txtNum = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.lbdo = New System.Windows.Forms.ListBox()
        Me.btnEmpezar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbProductos = New System.Windows.Forms.ListBox()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(13, 13)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(775, 425)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.lbProductos)
        Me.TabPage1.Controls.Add(Me.btnAgregar)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(767, 392)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Programa 1"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnAgregar
        '
        Me.btnAgregar.Location = New System.Drawing.Point(295, 313)
        Me.btnAgregar.Name = "btnAgregar"
        Me.btnAgregar.Size = New System.Drawing.Size(171, 54)
        Me.btnAgregar.TabIndex = 3
        Me.btnAgregar.Text = "Agregar"
        Me.btnAgregar.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(311, 25)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 36)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Arreglos"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.lbwhile)
        Me.TabPage2.Controls.Add(Me.txtNum)
        Me.TabPage2.Controls.Add(Me.Button2)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(767, 392)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Programa 2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(18, 117)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(233, 20)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Escriba un numero mayor que 0"
        '
        'lbwhile
        '
        Me.lbwhile.FormattingEnabled = True
        Me.lbwhile.ItemHeight = 20
        Me.lbwhile.Location = New System.Drawing.Point(297, 40)
        Me.lbwhile.Name = "lbwhile"
        Me.lbwhile.Size = New System.Drawing.Size(413, 204)
        Me.lbwhile.TabIndex = 5
        '
        'txtNum
        '
        Me.txtNum.Location = New System.Drawing.Point(84, 155)
        Me.txtNum.Name = "txtNum"
        Me.txtNum.Size = New System.Drawing.Size(100, 26)
        Me.txtNum.TabIndex = 4
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(297, 266)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(171, 54)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Empezar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(52, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(177, 36)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Ciclo While"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.lbdo)
        Me.TabPage3.Controls.Add(Me.btnEmpezar)
        Me.TabPage3.Controls.Add(Me.Label1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 29)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(767, 392)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Programa 3"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'lbdo
        '
        Me.lbdo.FormattingEnabled = True
        Me.lbdo.ItemHeight = 20
        Me.lbdo.Location = New System.Drawing.Point(138, 86)
        Me.lbdo.Name = "lbdo"
        Me.lbdo.Size = New System.Drawing.Size(468, 184)
        Me.lbdo.TabIndex = 4
        '
        'btnEmpezar
        '
        Me.btnEmpezar.Location = New System.Drawing.Point(275, 307)
        Me.btnEmpezar.Name = "btnEmpezar"
        Me.btnEmpezar.Size = New System.Drawing.Size(171, 54)
        Me.btnEmpezar.TabIndex = 3
        Me.btnEmpezar.Text = "Empezar"
        Me.btnEmpezar.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(242, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 36)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Ciclo Do"
        '
        'lbProductos
        '
        Me.lbProductos.FormattingEnabled = True
        Me.lbProductos.ItemHeight = 20
        Me.lbProductos.Location = New System.Drawing.Point(79, 74)
        Me.lbProductos.Name = "lbProductos"
        Me.lbProductos.Size = New System.Drawing.Size(606, 224)
        Me.lbProductos.TabIndex = 4
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents btnAgregar As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents btnEmpezar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lbwhile As ListBox
    Friend WithEvents txtNum As TextBox
    Friend WithEvents lbdo As ListBox
    Friend WithEvents lbProductos As ListBox
End Class
