﻿Public Class Form1
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim inicio As Integer
        Dim final As Integer

        inicio = 0
        final = txtNum.Text

        While inicio <= final
            lbwhile.Items.Add(inicio)
            inicio = inicio + 1
        End While
        lbwhile.Items.Add("Fin del programa")
    End Sub

    Private Sub btnEmpezar_Click(sender As Object, e As EventArgs) Handles btnEmpezar.Click
        Dim index As Integer
        index = 0
        Do Until index > 100
            lbdo.Items.Add(index)
            index += 1
        Loop
        lbdo.Items.Add("Fin del programa")
    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        Dim producto, mes As Integer
        Dim arreglo(0 To 3, 0 To 5) As Integer
        Const j = 0
        lbProductos.Items.Add(vbTab & vbTab & "Enero" & vbTab & "Febrero" & vbTab & "Marzo" & vbTab & "Abril" & vbTab & "Mayo" & vbTab & "Junio")
        lbProductos.Items.Add(vbTab & "____________________________________________")
        For producto = 0 To 3
            For mes = 0 To 5
                arreglo(producto, mes) = InputBox("Escriba la cantidad de ventas de:" & " " & "producto" & " " & producto & " " & "mes" & " " & mes)

            Next mes
        Next producto

        For i = 0 To 3

            lbProductos.Items.Add("Producto" & "" & i & vbTab & arreglo(i, j) & vbTab & arreglo(i, j + 1) & vbTab & arreglo(i, j + 2) _
& vbTab & arreglo(i, j + 3) & vbTab & arreglo(i, j + 4) & vbTab & arreglo(i, j + 5))

        Next i

    End Sub
End Class
